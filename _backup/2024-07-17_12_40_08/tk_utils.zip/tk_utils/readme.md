The `tk_utils` module
============================================================================


This folder should be placed directly under your toolkit project folder:

    ```
    toolkit/   
    | ...
    |__ tk_utils/           <- This folder
    ```

IMPORTANT: This module is should not be modified. Also, it includes Python
concepts/libraries we did not (and will not) discuss in this course. Please
use this module "as is" and do not worry about the implementation.








